# For the YouTube Data API
PLAYLIST_ID = ""

# For the Spotify Web API
CLIENT_ID = ""
CLIENT_SECRET = ""
USER_ID = ""
REDIRECT_URI = ""